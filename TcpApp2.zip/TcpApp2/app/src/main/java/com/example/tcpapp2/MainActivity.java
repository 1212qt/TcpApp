package com.example.tcpapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import com.example.tcpapp2.TcpConnection.Connector;

import org.json.JSONException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void runOtherActivity(View view){
        EditText ip = findViewById(R.id.ipEditText);
        EditText port = findViewById(R.id.portEditText);
        if(!ip.getText().toString().isEmpty() &&
            !port.getText().toString().isEmpty()){

            Intent intent = new Intent(this, ParametersActivity.class);
            intent.putExtra("ip", ip.getText().toString());
            intent.putExtra("port", port.getText().toString());
            startActivity(intent);
        }
    }
}
