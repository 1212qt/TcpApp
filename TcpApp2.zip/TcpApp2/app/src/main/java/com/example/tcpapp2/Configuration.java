package com.example.tcpapp2;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;

import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Vector;

import javax.xml.parsers.*;

public class Configuration {
    private static String loadJSONconfiguration(Context p_context){
        String l_jsonString = null;
        try(InputStream inputStream = p_context.getAssets().open("setup.json")) {
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            l_jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }

        return l_jsonString;
    }

    public static void loadWritableParametersToView (Context p_context,ViewGroup p_view) {
        JSONObject jsonObject = null;
        try {
            jsonObject = new JSONObject(loadJSONconfiguration(p_context));

            JSONArray writables = jsonObject.getJSONArray("WritableParameter");
            List<Configuration.WritableParameter> l_list = new Vector();


            for (int i = 0; i < writables.length(); i++) {
                JSONObject l_obj = writables.getJSONObject(i);
                l_list.add(new Configuration.WritableParameter());
                l_list.get(i).name = l_obj.getString("name");
                if ((l_list.get(i).type = l_obj.getString("type")) == "int") {
                    l_list.get(i).intVal = l_obj.getInt("value");
                }
                else {
                    l_list.get(i).doubleVal = l_obj.getDouble("value");
                }
                l_list.get(i).min = l_obj.getInt("min");
                l_list.get(i).max = l_obj.getInt("max");
                l_list.get(i).address = Integer.decode(l_obj.getString("address"));

//                LinearLayout l = new LinearLayout(p_context);
//                TextView t = new TextView(p_context);
//                TextView b = new TextView(p_context);
//                l.addView(t);
//                l.addView(b);
//                t.setText("sraka");
//                p_view.addView(l);
//                l.setOrientation(LinearLayout.HORIZONTAL);
//                t.setText(l_list.get(i).name);

                LayoutInflater inflater = LayoutInflater.from(p_context);
                ConstraintLayout rowView = (ConstraintLayout) inflater.inflate(R.layout.row, p_view, false);
                TextInputLayout input = rowView.findViewById(R.id.input);
                input.setHint(l_list.get(i).name);
                p_view.addView(rowView);

            }
            Log.i("oko", Double.toString(l_list.get(0).address));
            Log.i("oko", Double.toString(l_list.get(2).address));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    static class WritableParameter{
        String name;
        String type;
        int min;
        int max;
        int intVal;
        double doubleVal;
        int address;
    }
//    private static String xml = Resources.getXml(R.xml.file);/*"<fields>" +
//            "<writable>" +
//                "<field name=\"Nastawa\" min=\"-1\" max=\"0\"/>" +
//            "</writable>" +
//            "<readable>" +
//                "<field name=\"Wartosc skuteczna\" address=\"0x00000F00\"/>" +
//            "</readable>" +
//            "</fields>"; */
//    public static List<WritableField> getWritableFields() throws ParserConfigurationException, IOException, SAXException {
//        List result = new ArrayList<WritableField>();
//        DocumentBuilderFactory factory =
//                DocumentBuilderFactory.newInstance();
//        DocumentBuilder builder = factory.newDocumentBuilder();
//        Document document = builder.parse(xml);
//        Node writableFields = document.getElementsByTagName("writable").item(0);
//        for (int i = 0; i < writableFields.getChildNodes().getLength(); ++i) {
//            Node child = writableFields.getChildNodes().item(i);
//
//            result.add(new WritableField(
//                    child.getAttributes().getNamedItem("name"),
//                    Double.parseDouble(child.getAttributes().getNamedItem("min").getTextContent()),
//                    Double.parseDouble(child.getAttributes().getNamedItem("max").getTextContent())
//            ));
//        }
//
//        return result;
//    }
//    private static class WritableField {
//        String name;
//        double min, max;
//        public WritableField(String name, double min, double max) {
//            this.name = name;
//            this.min = min;
//            this.max= max;
//        }
//    }
//    private static class ReadableField {
//        String name, address;
//        public ReadableField(String name, String address) {
//            this.name = name;
//            this.address = address;
//        }
//    }
}
