package com.example.tcpapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.tcpapp2.TcpConnection.Connector;

import java.io.IOException;
import java.net.Socket;
import java.util.List;

public class Activity extends AppCompatActivity {
    Thread m_connectionThread;
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_params);
        Intent intent = getIntent();
        String ip = intent.getStringExtra("ip");
        int port = Integer.parseInt(intent.getStringExtra("port"));

        m_connectionThread = new Thread(() -> {
            Socket l_socket = null;
            try {
                l_socket = new Socket(ip, port);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                List<List<Double>> l_list = Connector.TcpReadScopeBufferDirect(l_socket,0, 0, 0, 0, 2048);
                l_socket.close();
            } catch (InterruptedException e) {
                e.printStackTrace();
                try {
                    if (l_socket.isConnected())
                        l_socket.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            } catch (IOException e) {

            }
        });
        m_connectionThread.interrupt();
        m_connectionThread.start();
        //Log.i("dupsko", "na koncu f");


    }
    @Override
    protected void onPause(){
        super.onPause();
        Log.i("dfsj", "on pause");
    }



    @Override
    protected void onStop(){
        super.onStop();
        if(m_connectionThread.isAlive()){
            m_connectionThread.interrupt();
        }

        Log.i("oko", "ondestroy");
    }

    public void end(View view){
        this.finish();
    }

}
