package com.example.tcpapp2;

import android.os.Bundle;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;

public class ParametersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_params);
        LinearLayout l_layout = findViewById(R.id.linearLayout);


        Configuration.loadWritableParametersToView(this, l_layout);

    }
}
